#define VERSION 6.04
#define VERSION_STR "6.04"
#define VERSION_MAJOR 6
#define VERSION_MINOR 4
#define YEAR 2015
#define YEAR_STR "2015"
